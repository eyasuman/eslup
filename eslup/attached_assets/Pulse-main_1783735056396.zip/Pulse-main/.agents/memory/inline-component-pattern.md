---
name: Inline component anti-pattern
description: Defining a React component (even a simple wrapper) inside another component's render function causes "Invalid hook call" errors.
---

## The Rule
Never define a React component inside another component's render function.

```tsx
// BAD — crashes with "Invalid hook call"
function MyScreen() {
  const Container = isDark
    ? ({ children }) => <LinearGradient>{children}</LinearGradient>
    : ({ children }) => <View>{children}</View>;
  return <Container>...</Container>;
}

// GOOD — define at module level
function DarkContainer({ children }) { return <LinearGradient>{children}</LinearGradient>; }
function LightContainer({ children }) { return <View>{children}</View>; }

function MyScreen() {
  const Container = isDark ? DarkContainer : LightContainer;
  return <Container>...</Container>;
}
```

**Why:** On every render, a new function reference is created. React compares component types by reference, so React unmounts the old subtree and mounts a new one on every render. Hooks inside the remounted subtree are called during the unmount cycle, triggering "Invalid hook call".

**How to apply:** When reviewing Expo/React Native files, grep for `const Container =` or any component defined inside a render function. Move them to module scope.
