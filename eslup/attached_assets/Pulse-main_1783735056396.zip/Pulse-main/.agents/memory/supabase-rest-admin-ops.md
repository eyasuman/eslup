---
name: Supabase REST admin ops via curl
description: How to perform Supabase admin/storage/auth operations (bucket creation, RLS testing, table inspection) from the agent sandbox when no direct Postgres connection to the Supabase project is available.
---

The `code_execution` JS sandbox does not expose `process.env` (secrets aren't injected there), and installing `@supabase/supabase-js` ad hoc fails with module-not-found. Use the `bash` tool instead — it has the real env vars — and hit Supabase's REST/Storage/Auth APIs directly with `curl`, authenticating with `SUPABASE_SERVICE_ROLE_KEY` (and `apikey` header set to the same value; both headers are required or you get "Invalid Compact JWS"/401).

**Why:** Supabase projects often use a different Postgres instance than the workspace's own `DATABASE_URL` (e.g. a Replit-managed Postgres for an API server vs. the project's actual Supabase Postgres) — there is no generic direct SQL path, but the REST endpoints (`/rest/v1/<table>`, `/storage/v1/bucket`, `/auth/v1/admin/users`) work universally with the service role key.

**How to apply:**
- List/inspect table schema: `GET {SUPABASE_URL}/rest/v1/` returns OpenAPI `definitions` per table — useful for checking column names/types without DB access.
- Create a storage bucket: `POST {SUPABASE_URL}/storage/v1/bucket` with service role key, `{"id","name","public","file_size_limit","allowed_mime_types"}`.
- To test whether RLS is correctly configured (not just "does service role bypass it"), create a throwaway user via `POST /auth/v1/admin/users` (service key), sign in via `POST /auth/v1/token?grant_type=password` (anon key) to get a real JWT, then use that JWT as `Authorization: Bearer` for insert/update/select checks — this simulates what the actual app experiences. Clean up the test user/rows afterward with the service key.
- A "row violates row-level security policy" error on an anon-key (no session) insert is often *correct* behavior, not a bug — verify against an authenticated session before concluding RLS is broken.

## Direct Postgres access (DDL) to a Supabase project

The REST API can't run DDL (e.g. `ALTER TABLE ... ADD COLUMN`). For that you need a direct `psql`/Postgres connection string from the user (Project Settings → Database → Connection string), not just the service role key.

**Gotcha 1 — IPv6-only direct host:** Supabase's default direct host (`db.<project-ref>.supabase.co`) often resolves to IPv6 only. This sandbox has no IPv6 route, so `psql` fails with a bare `psql: error:` (empty message) — not a helpful error. Check with `getent hosts db.<ref>.supabase.co`; if it only returns an IPv6-looking address, don't waste time retrying the same host.

**Fix — use the Supabase Session Pooler instead**, which is IPv4-reachable: host `aws-0-<region>.pooler.supabase.com:5432`, user `postgres.<project-ref>` (note the dot, not the plain `postgres` user), same password. The region isn't guessable from the project ref — if unknown, brute-force try common regions (`us-east-1`, `us-east-2`, `us-west-1`, `eu-west-1`, `eu-central-1`, `ap-southeast-1`, ...) with a short `PGCONNECT_TIMEOUT` until one connects; wrong region gives a clean `tenant/user ... not found` error (fast-fail), not a timeout.

**Gotcha 2 — pasted connection strings often have a leftover bracket:** users frequently copy the string with `[YOUR-PASSWORD]` and only replace the text inside, leaving stray `[`/`]` characters glued to the real password (e.g. `:[realpasswordXYZ@]@db...`). Inspect the raw env var char-by-char (without printing the password) with `python3 -c "import os; s=os.environ['VAR']; print(s.find('['), s.find(']'))"` to detect and strip these before use, rather than assuming the string is well-formed.

## Storage buckets referenced in code may not actually exist / lack RLS policies

Grep the codebase for every `supabase.storage.from("<bucket>")` call and diff that list against `GET /storage/v1/bucket` — apps frequently reference buckets (e.g. per-feature uploads like licenses, payment proofs, avatars, scans) that were never created in the actual Supabase project, so those upload flows silently fail (often swallowed by a try/catch) even though the code looks complete.

**Why:** newly created buckets have no storage.objects RLS policies by default — even after creating the bucket, authenticated inserts get rejected with "new row violates row-level security policy" until explicit policies are added for `INSERT`/`SELECT` (and `UPDATE` if using `upsert: true`) scoped to `bucket_id = '<name>'`.

**How to apply:** when asked to make an upload feature "work," don't stop at creating the bucket — test an authenticated insert (see auth-testing pattern above) and add `CREATE POLICY ... ON storage.objects FOR INSERT/SELECT/UPDATE TO authenticated USING/WITH CHECK (bucket_id = '<name>')` via direct psql if it fails. Keep sensitive-document buckets (medical records, licenses) private and access them via signed URLs generated server-side, not public URLs.

## Table inserts silently no-op when the code writes columns the table doesn't have

PostgREST rejects inserts containing any column not in the table's schema (whole insert fails, not just that field). If the calling code wraps the insert in try/catch and swallows the error (common pattern: "Supabase unavailable — local state still saved"), the row is never created and the bug looks like a downstream feature (e.g. realtime status checks) failing for no reason.

**Why:** it's easy to add a new form field / write path in app code (e.g. payment proof metadata) without also running the matching `ALTER TABLE`, since nothing throws visibly in the UI.

**How to apply:** when a feature that depends on a table row appearing in Supabase seems flaky (e.g. "doesn't unlock", "admin never sees it"), diff the exact keys in the insert/update call against `\d public.<table>` (or the REST OpenAPI `definitions`) before assuming the bug is in RLS or business logic. Also check for tables referenced in code (e.g. a `notifications` table with insert/select helpers) that don't exist in the DB at all — those helpers are often wrapped in try/catch too ("table may not exist"), masking a completely missing feature.
