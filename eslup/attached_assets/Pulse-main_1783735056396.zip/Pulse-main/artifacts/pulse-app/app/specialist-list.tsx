import { Feather } from "@expo/vector-icons";
import * as Haptics from "expo-haptics";
import { router, useLocalSearchParams } from "expo-router";
import React, { useMemo, useState } from "react";
import {
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ETHIOPIAN_DOCTORS } from "@/data/ethiopianDoctors";
import { useApp } from "@/context/AppContext";
import { useColors } from "@/hooks/useColors";

export default function SpecialistListScreen() {
  const { specialty, category } = useLocalSearchParams<{ specialty: string; category: string }>();
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { addBooking } = useApp();
  const [sortBy, setSortBy] = useState<"rating" | "price" | "experience">("rating");
  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const bottomPad = Platform.OS === "web" ? 34 : insets.bottom;

  const bg = colors.isDark ? colors.background : "#FFFFFF";
  const textPrimary = colors.isDark ? "#FFFFFF" : "#202937";
  const textMuted = colors.isDark ? "#94A3B8" : "#64748B";
  const cardBg = colors.isDark ? "rgba(255,255,255,0.06)" : "#F4F7FB";
  const borderCol = colors.isDark ? "rgba(255,255,255,0.1)" : "#E2E8F0";

  const doctors = useMemo(() => {
    const base = specialty
      ? ETHIOPIAN_DOCTORS.filter((d) => d.specialty.toLowerCase() === specialty.toLowerCase())
      : ETHIOPIAN_DOCTORS;
    const list = base.length > 0 ? base : ETHIOPIAN_DOCTORS;
    return [...list].sort((a, b) => {
      if (sortBy === "rating") return b.rating - a.rating;
      if (sortBy === "price") return a.price - b.price;
      if (sortBy === "experience") return b.experience - a.experience;
      return 0;
    });
  }, [specialty, sortBy]);

  return (
    <View style={[styles.container, { backgroundColor: bg }]}>
      {/* Header */}
      <View style={[styles.header, { paddingTop: topPad + 10, backgroundColor: "#202937", paddingHorizontal: 20, paddingBottom: 20 }]}>
        <Pressable onPress={() => router.back()} style={styles.backBtn}>
          <Feather name="arrow-left" size={22} color="#fff" />
          <Text style={styles.backText}>Back</Text>
        </Pressable>
        <Text style={styles.headerTitle}>{specialty ?? "All Providers"}</Text>
        <Text style={styles.headerSub}>{doctors.length} provider{doctors.length !== 1 ? "s" : ""} found</Text>

        {/* Sort Options */}
        <View style={styles.sortRow}>
          {(["rating", "price", "experience"] as const).map((s) => (
            <Pressable
              key={s}
              onPress={() => setSortBy(s)}
              style={[
                styles.sortChip,
                { backgroundColor: sortBy === s ? "#315d93" : "rgba(255,255,255,0.12)" },
              ]}
            >
              <Text style={[styles.sortChipText, { color: sortBy === s ? "#fff" : "rgba(255,255,255,0.7)" }]}>
                {s.charAt(0).toUpperCase() + s.slice(1)}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      <FlatList
        data={doctors}
        keyExtractor={(item) => item.id}
        contentContainerStyle={{ padding: 16, gap: 14, paddingBottom: bottomPad + 110 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <Pressable
            onPress={() => {
              Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
              router.push({ pathname: "/provider-detail", params: { id: item.id } });
            }}
            style={({ pressed }) => [
              styles.card,
              { backgroundColor: cardBg, borderColor: borderCol, opacity: pressed ? 0.88 : 1 },
            ]}
          >
            <View style={styles.cardTop}>
              <View style={[styles.avatar, { backgroundColor: "#315d93" + "20" }]}>
                <Feather name="user" size={30} color="#315d93" />
                {item.onlineStatus && <View style={styles.onlineDot} />}
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.docName, { color: textPrimary }]}>{item.name}</Text>
                <Text style={[styles.docSpec, { color: "#315d93" }]}>{item.specialty}</Text>
                <View style={styles.locRow}>
                  <Feather name="map-pin" size={11} color={textMuted} />
                  <Text style={[styles.locText, { color: textMuted }]}>{item.hospital} · {item.city}</Text>
                </View>
              </View>
              <View style={styles.ratingCol}>
                <Feather name="star" size={13} color="#D97706" />
                <Text style={[styles.ratingVal, { color: textPrimary }]}>{item.rating}</Text>
              </View>
            </View>

            <Text style={[styles.bio, { color: textMuted }]} numberOfLines={2}>{item.bio}</Text>

            <View style={styles.cardMeta}>
              <View style={styles.metaItem}>
                <Feather name="clock" size={12} color={textMuted} />
                <Text style={[styles.metaText, { color: textMuted }]}>{item.experience}y exp</Text>
              </View>
              <View style={styles.metaDot} />
              <Text style={[styles.price, { color: "#059669" }]}>
                {(item.price / 100).toFixed(0)} {item.currency}
              </Text>
              <View style={{ flex: 1 }} />
              <View style={[styles.availBadge, { backgroundColor: item.available ? "#059669" + "20" : "#64748B" + "20" }]}>
                <Text style={[styles.availText, { color: item.available ? "#059669" : "#64748B" }]}>
                  {item.available ? "Available" : "Busy"}
                </Text>
              </View>
            </View>

            <View style={styles.tags}>
              {item.consultationTypes.map((ct) => (
                <View key={ct} style={[styles.tag, { backgroundColor: "#315d93" + "12", borderColor: "#315d93" + "25" }]}>
                  <Feather
                    name={ct === "video" ? "video" : ct === "phone" ? "phone" : "home"}
                    size={10}
                    color="#315d93"
                  />
                  <Text style={[styles.tagText, { color: "#315d93" }]}>{ct}</Text>
                </View>
              ))}
              {item.languages.slice(0, 2).map((lang) => (
                <View key={lang} style={[styles.tag, { backgroundColor: colors.isDark ? "rgba(255,255,255,0.06)" : "#F1F5F9", borderColor: borderCol }]}>
                  <Text style={[styles.tagText, { color: textMuted }]}>{lang}</Text>
                </View>
              ))}
            </View>

            <Pressable
              onPress={() => {
                Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                router.push({ pathname: "/booking", params: { doctorId: item.id, doctorName: item.name, specialty: item.specialty } });
              }}
              style={styles.bookBtn}
            >
              <Text style={styles.bookBtnText}>Book Now</Text>
            </Pressable>
          </Pressable>
        )}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {},
  backBtn: { flexDirection: "row", alignItems: "center", gap: 8, marginBottom: 12 },
  backText: { color: "rgba(255,255,255,0.8)", fontSize: 15, fontFamily: "Inter_500Medium" },
  headerTitle: { color: "#fff", fontSize: 22, fontFamily: "Inter_700Bold" },
  headerSub: { color: "rgba(255,255,255,0.65)", fontSize: 13, fontFamily: "Inter_400Regular", marginBottom: 12 },
  sortRow: { flexDirection: "row", gap: 8 },
  sortChip: { paddingHorizontal: 14, paddingVertical: 7, borderRadius: 20 },
  sortChipText: { fontSize: 12, fontFamily: "Inter_500Medium" },
  card: { borderRadius: 15, borderWidth: 1, padding: 16, gap: 10 },
  cardTop: { flexDirection: "row", gap: 12, alignItems: "flex-start" },
  avatar: { width: 60, height: 60, borderRadius: 30, alignItems: "center", justifyContent: "center" },
  onlineDot: { position: "absolute", bottom: 2, right: 2, width: 12, height: 12, borderRadius: 6, backgroundColor: "#059669", borderWidth: 2, borderColor: "#fff" },
  docName: { fontSize: 15, fontFamily: "Inter_700Bold" },
  docSpec: { fontSize: 13, fontFamily: "Inter_500Medium", marginTop: 2 },
  locRow: { flexDirection: "row", alignItems: "center", gap: 4, marginTop: 4 },
  locText: { fontSize: 11, fontFamily: "Inter_400Regular" },
  ratingCol: { alignItems: "center", gap: 2 },
  ratingVal: { fontSize: 16, fontFamily: "Inter_700Bold" },
  reviewCnt: { fontSize: 10, fontFamily: "Inter_400Regular" },
  bio: { fontSize: 12, fontFamily: "Inter_400Regular", lineHeight: 18 },
  cardMeta: { flexDirection: "row", alignItems: "center", gap: 8 },
  metaItem: { flexDirection: "row", alignItems: "center", gap: 4 },
  metaText: { fontSize: 12, fontFamily: "Inter_400Regular" },
  metaDot: { width: 3, height: 3, borderRadius: 2, backgroundColor: "#94A3B8" },
  price: { fontSize: 14, fontFamily: "Inter_700Bold" },
  availBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 8 },
  availText: { fontSize: 11, fontFamily: "Inter_600SemiBold" },
  tags: { flexDirection: "row", flexWrap: "wrap", gap: 6 },
  tag: { flexDirection: "row", alignItems: "center", gap: 4, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, borderWidth: 1 },
  tagText: { fontSize: 10, fontFamily: "Inter_500Medium" },
  bookBtn: { backgroundColor: "#202937", borderRadius: 12, padding: 12, alignItems: "center", marginTop: 2 },
  bookBtnText: { color: "#fff", fontSize: 14, fontFamily: "Inter_700Bold" },
});
