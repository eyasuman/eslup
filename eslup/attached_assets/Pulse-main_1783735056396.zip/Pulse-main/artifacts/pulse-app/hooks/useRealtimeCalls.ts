import { useEffect, useRef, useState } from "react";
import { Call, subscribeToIncomingCalls, updateCallStatus } from "@/services/callService";

export function useRealtimeCalls(doctorUserId: string | undefined) {
  const [incomingCall, setIncomingCall] = useState<Call | null>(null);
  const channelRef = useRef<ReturnType<typeof subscribeToIncomingCalls> | null>(null);

  useEffect(() => {
    if (!doctorUserId) return;

    channelRef.current = subscribeToIncomingCalls(doctorUserId, (call) => {
      if (call.status === "waiting") {
        setIncomingCall(call);
      }
    });

    return () => {
      if (channelRef.current) {
        channelRef.current.unsubscribe();
        channelRef.current = null;
      }
    };
  }, [doctorUserId]);

  const acceptCall = async (call: Call) => {
    await updateCallStatus(call.id, "accepted");
    setIncomingCall(null);
    return call.room_name;
  };

  const rejectCall = async (call: Call) => {
    await updateCallStatus(call.id, "rejected");
    setIncomingCall(null);
  };

  const dismissCall = () => {
    setIncomingCall(null);
  };

  return { incomingCall, acceptCall, rejectCall, dismissCall };
}
