import { createClient } from "@supabase/supabase-js";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { Platform } from "react-native";

const SUPABASE_URL =
  process.env.EXPO_PUBLIC_SUPABASE_URL || "https://placeholder.supabase.co";
const SUPABASE_ANON_KEY =
  process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || "placeholder_anon_key";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: Platform.OS === "web",
    storage: {
      getItem: (key: string) => AsyncStorage.getItem(key),
      setItem: (key: string, value: string) => AsyncStorage.setItem(key, value),
      removeItem: (key: string) => AsyncStorage.removeItem(key),
    },
  },
});

/**
 * Fetch a system setting by its key
 */
export async function getSetting(key: string): Promise<string | null> {
  const { data, error } = await supabase
    .from("settings")
    .select("*");
  
  if (error) return null;
  
  const setting = data?.find((s: any) => {
    const k = (s.key || s.name || s.setting_key || s.id || s.identifier || s.key_name || "").toLowerCase();
    return k === key.toLowerCase();
  });

  const val = setting?.value || setting?.val || setting?.setting_value || setting?.content || setting?.data || setting?.v || setting?.json_data;
  return val ? String(val) : null;
}

// ─── AUTH ──────────────────────────────────────────────────────────────────────

export async function signUp(email: string, password: string, name: string, role: string) {
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: { data: { name, role } },
  });
  if (error) throw error;
  return data;
}

export async function signIn(email: string, password: string) {
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

export async function signOut() {
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getCurrentSession() {
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  return data.session;
}

export async function getCurrentUser() {
  const { data, error } = await supabase.auth.getUser();
  if (error) throw error;
  return data.user;
}

// ─── DOCTORS (PROVIDERS) ─────────────────────────────────────────────────────
// The `doctors` table uses "userId" (camelCase) as the foreign key to auth.users

export async function getDoctorByUserId(userId: string) {
  const { data, error } = await supabase
    .from("doctors")
    .select("*")
    .eq("userId", userId)
    .single();
  if (error) throw error;
  return data;
}

export async function getApprovedDoctors() {
  const { data, error } = await supabase
    .from("doctors")
    .select("*")
    .eq("status", "Active")
    .order("updatedAt", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function getAllDoctorsForAdmin() {
  const { data, error } = await supabase
    .from("doctors")
    .select("*")
    .order("updatedAt", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export function subscribeToProviders(callback: (payload: any) => void) {
  return supabase
    .channel("providers:all")
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "doctors" },
      callback
    )
    .subscribe();
}

export function subscribeToProviderStatusChanges(
  userId: string,
  onStatusChange: (newStatus: string, fullRecord: any) => void
) {
  return supabase
    .channel(`provider:status:${userId}`)
    .on(
      "postgres_changes",
      {
        event: "UPDATE",
        schema: "public",
        table: "doctors",
        filter: `userId=eq.${userId}`,
      },
      (payload) => {
        const record = payload.new as any;
        if (record?.status) {
          onStatusChange(record.status, record);
        }
      }
    )
    .subscribe();
}

export async function upsertDoctor(doctor: {
  userId: string;
  name: string;
  email: string;
  providerType: string;
  specialty: string;
  city?: string;
  experienceYears?: number;
  bio?: string;
  phone?: string;
  licenseNo?: string;
  consultationFee?: number;
  serviceModes?: Record<string, boolean>;
  availability?: any[];
  status?: string;
  licenseFile?: Record<string, any> | null;
  telebirrMerchant?: string;
  cbeAccount?: string;
}) {
  const payload: any = {
    ...doctor,
    status: doctor.status ?? "Pending",
    serviceModes: doctor.serviceModes ?? { video: true, audio: false, inPerson: true, homeVisit: false },
    availability: doctor.availability ?? [],
    updatedAt: new Date().toISOString(),
  };
  const { data, error } = await supabase
    .from("doctors")
    .upsert(payload, { onConflict: "userId" })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function updateProviderPaymentInfo(userId: string, info: { telebirrMerchant?: string; cbeAccount?: string }) {
  const { error } = await supabase
    .from("doctors")
    .update({ ...info, updatedAt: new Date().toISOString() })
    .eq("userId", userId);
  if (error) throw error;
}

export async function updateDoctorOnlineStatus(userId: string, isOnline: boolean) {
  const { error } = await supabase
    .from("doctors")
    .update({
      availability: isOnline ? [{ active: true, mode: "online" }] : [],
      updatedAt: new Date().toISOString(),
    })
    .eq("userId", userId);
  if (error) throw error;
}

export async function updateDoctorConsultationFee(userId: string, fee: number) {
  const { error } = await supabase
    .from("doctors")
    .update({ consultationFee: fee, updatedAt: new Date().toISOString() })
    .eq("userId", userId);
  if (error) throw error;
}

export async function updateDoctorServiceModes(userId: string, serviceModes: Record<string, boolean>) {
  const { error } = await supabase
    .from("doctors")
    .update({ serviceModes, updatedAt: new Date().toISOString() })
    .eq("userId", userId);
  if (error) throw error;
}

export async function updateDoctorAvailabilitySchedule(userId: string, availability: any[]) {
  const { error } = await supabase
    .from("doctors")
    .update({ availability, updatedAt: new Date().toISOString() })
    .eq("userId", userId);
  if (error) throw error;
}

// Legacy alias used by dashboard.tsx
export async function updateProviderAvailability(
  userId: string,
  available: boolean,
  _onlineStatus: boolean
) {
  return updateDoctorOnlineStatus(userId, available);
}

// ─── PROFILE IMAGE UPLOAD ──────────────────────────────────────────────────────

export async function uploadProfileImage(userId: string, imageUri: string): Promise<string> {
  const ext = imageUri.split(".").pop()?.split("?")[0] ?? "jpg";
  const fileName = `${userId}/avatar_${Date.now()}.${ext}`;
  const response = await fetch(imageUri);
  const blob = await response.blob();
  const { error } = await supabase.storage
    .from("profile-images")
    .upload(fileName, blob, { contentType: `image/${ext}`, upsert: true });
  if (error) throw error;
  const { data: urlData } = supabase.storage.from("profile-images").getPublicUrl(fileName);
  await supabase
    .from("doctors")
    .update({ updatedAt: new Date().toISOString() })
    .eq("userId", userId);
  return urlData.publicUrl;
}

// ─── PAYMENT PROOF UPLOAD ──────────────────────────────────────────────────────

export async function uploadPaymentProof(userId: string, imageUri: string): Promise<string> {
  const ext = imageUri.split(".").pop()?.split("?")[0] ?? "jpg";
  const fileName = `payment_proofs/${userId}_${Date.now()}.${ext}`;
  const response = await fetch(imageUri);
  const blob = await response.blob();
  
  const { data, error } = await supabase.storage
    .from("payment-proofs")
    .upload(fileName, blob, { contentType: `image/${ext}`, upsert: true });
    
  if (error) throw error;
  
  const { data: urlData } = supabase.storage.from("payment-proofs").getPublicUrl(data.path);
  return urlData.publicUrl;
}

// ─── MEDICAL LICENSE UPLOAD ────────────────────────────────────────────────────

export async function uploadMedicalLicense(
  userId: string,
  file: { name: string; type: string; uri: string }
): Promise<string> {
  const fileName = `${userId}/license_${Date.now()}_${file.name}`;
  const blob = await fetch(file.uri).then((r) => r.blob());
  const { data, error } = await supabase.storage
    .from("medical-licenses")
    .upload(fileName, blob, { contentType: file.type, upsert: true });
  if (error) throw error;
  await supabase
    .from("doctors")
    .update({
      licenseFile: { path: data.path, name: file.name, type: file.type },
      updatedAt: new Date().toISOString(),
    })
    .eq("userId", userId);
  return data.path;
}

// ─── APPOINTMENTS ─────────────────────────────────────────────────────────────
// The `appointments` table uses camelCase column names:
// patientId, doctorId, doctorUserId, doctorName, serviceType, consultationFee, etc.

export async function createAppointment(appt: {
  patientId: string;
  patientName?: string;
  patientEmail?: string;
  doctorId?: string;
  doctorUserId?: string;
  doctorName?: string;
  specialty?: string;
  date: string;
  serviceType?: string;
  consultationFee?: number;
  platformFee?: number;
  totalPrice?: number;
  notes?: string;
  telebirrMerchant?: string;
  cbeAccount?: string;
  paymentProofUrl?: string;
  paymentMethod?: string;
  transactionId?: string;
  senderName?: string;
}) {
  const { data, error } = await supabase
    .from("appointments")
    .insert({
      ...appt,
      status: "pending",
      paymentStatus: "pending",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function getAppointmentsForClient(patientId: string) {
  const { data, error } = await supabase
    .from("appointments")
    .select("*")
    .eq("patientId", patientId)
    .order("createdAt", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function getAppointmentsForProvider(doctorUserId: string) {
  const { data, error } = await supabase
    .from("appointments")
    .select("*")
    .eq("doctorUserId", doctorUserId)
    .order("createdAt", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function updateAppointmentStatus(appointmentId: string, status: string) {
  const { error } = await supabase
    .from("appointments")
    .update({ status, updatedAt: new Date().toISOString() })
    .eq("id", appointmentId);
  if (error) throw error;
}

// Legacy alias
export async function updateBookingStatus(appointmentId: string, status: string) {
  return updateAppointmentStatus(appointmentId, status);
}

// ─── PROVIDER STATS ────────────────────────────────────────────────────────────

export async function getProviderStats(userId: string) {
  const now = new Date();
  const firstOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();

  const [allRes, monthRes] = await Promise.all([
    supabase
      .from("appointments")
      .select("id, totalPrice, consultationFee")
      .eq("doctorUserId", userId)
      .eq("status", "completed"),
    supabase
      .from("appointments")
      .select("id, totalPrice, consultationFee")
      .eq("doctorUserId", userId)
      .gte("createdAt", firstOfMonth),
  ]);

  const all = allRes.data ?? [];
  const month = monthRes.data ?? [];

  return {
    totalClients: all.length,
    thisMonth: month.length,
    avgRating: "4.8",
    totalEarnings: all.reduce((s: number, b: any) => s + (b.totalPrice ?? b.consultationFee ?? 0), 0),
    monthEarnings: month.reduce((s: number, b: any) => s + (b.totalPrice ?? b.consultationFee ?? 0), 0),
  };
}

// ─── RADIOLOGY (using medicalRecords table) ───────────────────────────────────

export async function submitRadiologyCase(caseData: {
  submitted_by: string;
  patient_name: string;
  patient_age: number;
  patient_gender: string;
  scan_type: string;
  body_part: string;
  urgency: string;
  symptoms?: string;
  assigned_radiologist_name?: string;
  scan_image_uri?: string | null;
}) {
  let fileUrl: string | null = null;

  if (caseData.scan_image_uri) {
    try {
      const ext = caseData.scan_image_uri.split(".").pop()?.split("?")[0] ?? "jpg";
      const fileName = `${caseData.submitted_by}/${Date.now()}_scan.${ext}`;
      const blob = await fetch(caseData.scan_image_uri).then((r) => r.blob());
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from("radiology-scans")
        .upload(fileName, blob, { contentType: `image/${ext}`, upsert: true });
      if (!uploadError) fileUrl = uploadData.path;
    } catch {}
  }

  const { data, error } = await supabase
    .from("medicalRecords")
    .insert({
      patientId: caseData.submitted_by,
      providerUserId: caseData.submitted_by,
      type: "image",
      title: `${caseData.scan_type} — ${caseData.body_part}`,
      fileUrl,
      patientName: caseData.patient_name,
      consultationType: caseData.scan_type,
      notes: [
        `Patient: ${caseData.patient_name}`,
        `Age: ${caseData.patient_age}`,
        `Gender: ${caseData.patient_gender}`,
        `Urgency: ${caseData.urgency}`,
        caseData.symptoms ? `Symptoms: ${caseData.symptoms}` : null,
        caseData.assigned_radiologist_name ? `Radiologist: ${caseData.assigned_radiologist_name}` : null,
      ].filter(Boolean).join(" | "),
      summary: "pending",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    })
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function getRadiologyCases(userId: string) {
  const { data, error } = await supabase
    .from("medicalRecords")
    .select("*")
    .eq("patientId", userId)
    .eq("type", "image")
    .order("createdAt", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

export async function getRadiologyQueue(_radiologistId: string) {
  const { data, error } = await supabase
    .from("medicalRecords")
    .select("*")
    .eq("type", "image")
    .order("createdAt", { ascending: true });
  if (error) throw error;
  return data ?? [];
}

export async function submitRadiologyReport(report: {
  case_id: string;
  radiologist_id: string;
  radiologist_name: string;
  findings: string;
  impression: string;
  recommendations?: string;
}) {
  const summary = [
    `Findings: ${report.findings}`,
    `Impression: ${report.impression}`,
    report.recommendations ? `Recommendations: ${report.recommendations}` : null,
  ].filter(Boolean).join("\n");

  const { error } = await supabase
    .from("medicalRecords")
    .update({
      summary,
      secureNote: `Reported by: ${report.radiologist_name}`,
      providerUserId: report.radiologist_id,
      updatedAt: new Date().toISOString(),
    })
    .eq("id", report.case_id);
  if (error) throw error;
  return { id: report.case_id };
}

export async function getRadiologyReports(userId: string) {
  const { data, error } = await supabase
    .from("medicalRecords")
    .select("*")
    .eq("patientId", userId)
    .eq("type", "image")
    .not("summary", "eq", "pending")
    .order("updatedAt", { ascending: false });
  if (error) throw error;
  return data ?? [];
}

// ─── NOTIFICATIONS ────────────────────────────────────────────────────────────

export async function createNotification(n: { user_id: string; title: string; body: string; type: string }) {
  try {
    const { error } = await supabase
      .from("notifications")
      .insert({ ...n, read: false, created_at: new Date().toISOString() });
    if (error) throw error;
  } catch {
    // notifications table may not exist
  }
}

export async function getNotifications(userId: string) {
  try {
    const { data, error } = await supabase
      .from("notifications")
      .select("*")
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(50);
    if (error) throw error;
    return data ?? [];
  } catch {
    return [];
  }
}

export async function markNotificationsRead(userId: string) {
  try {
    await supabase.from("notifications").update({ read: true }).eq("user_id", userId);
  } catch {}
}

// ─── REALTIME SUBSCRIPTIONS ───────────────────────────────────────────────────

export function subscribeToClientBookings(
  patientId: string,
  onUpdate: (appt: any, eventType: "INSERT" | "UPDATE" | "DELETE") => void
) {
  return supabase
    .channel(`appointments:patient:${patientId}`)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "appointments", filter: `patientId=eq.${patientId}` },
      (payload) => onUpdate(payload.new ?? payload.old, payload.eventType as any)
    )
    .subscribe();
}

export function subscribeToProviderBookings(
  doctorUserId: string,
  onUpdate: (appt: any, eventType: "INSERT" | "UPDATE" | "DELETE") => void
) {
  return supabase
    .channel(`appointments:doctor:${doctorUserId}`)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "appointments", filter: `doctorUserId=eq.${doctorUserId}` },
      (payload) => onUpdate(payload.new ?? payload.old, payload.eventType as any)
    )
    .subscribe();
}

export function subscribeToNotifications(userId: string, onNew: (notification: any) => void) {
  return supabase
    .channel(`notifications:${userId}`)
    .on(
      "postgres_changes",
      { event: "INSERT", schema: "public", table: "notifications", filter: `user_id=eq.${userId}` },
      (payload) => onNew(payload.new)
    )
    .subscribe();
}

export function subscribeToRadiologyCases(userId: string, onUpdate: (rec: any) => void) {
  return supabase
    .channel(`medical:${userId}`)
    .on(
      "postgres_changes",
      { event: "*", schema: "public", table: "medicalRecords", filter: `patientId=eq.${userId}` },
      (payload) => onUpdate(payload.new)
    )
    .subscribe();
}

// ─── REVIEWS ──────────────────────────────────────────────────────────────────

export async function submitReview(review: {
  doctorId: string;
  patientId: string;
  patientName: string;
  rating: number;
  comment?: string;
}) {
  const { data, error } = await supabase
    .from("reviews")
    .insert({ ...review, status: "visible", createdAt: new Date().toISOString() })
    .select()
    .single();
  if (error) throw error;
  return data;
}

// ─── BANNERS ──────────────────────────────────────────────────────────────────

export async function getActiveBanners() {
  try {
    const { data, error } = await supabase
      .from("banners")
      .select("*")
      .eq("isActive", true)
      .order("priority", { ascending: false });
    if (error) throw error;
    return data ?? [];
  } catch {
    return [];
  }
}

// ─── BACKWARD-COMPAT ALIASES ──────────────────────────────────────────────────

export const getProfile = getDoctorByUserId;
export const getBookingsForClient = getAppointmentsForClient;
export const getBookingsForProvider = getAppointmentsForProvider;
